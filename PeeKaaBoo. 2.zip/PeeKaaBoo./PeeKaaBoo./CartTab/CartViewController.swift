import UIKit

class CartViewController: UIViewController {

    @IBOutlet weak var deleteBtnView: UIView!
    @IBOutlet weak var backBtnView: UIView!
    @IBOutlet weak var proceedView: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var imageView: UIView!
    @IBOutlet weak var firstMainView: UIView!
    @IBOutlet weak var firstImageView: UIView!
    @IBOutlet weak var checkBoxView: UIView!
    @IBOutlet weak var thirdImageView: UIView!
    @IBOutlet weak var thirdMainView: UIView!
    @IBOutlet weak var secondCheckBox: UIView!
    @IBOutlet weak var thirdCheckBox: UIView!
    
    var isChecked = [false, false, false]
    
    override func viewDidLoad() {
            super.viewDidLoad()
            
            setupCornerRadius()

            setupCheckbox(checkBoxView, tag: 0)
            setupCheckbox(secondCheckBox, tag: 1)
            setupCheckbox(thirdCheckBox, tag: 2)
        }

        func setupCornerRadius() {
            backBtnView.layer.cornerRadius = backBtnView.frame.height / 2
            deleteBtnView.layer.cornerRadius = deleteBtnView.frame.height / 2
            
            firstMainView.layer.cornerRadius = 10
            firstImageView.layer.cornerRadius = 10
            proceedView.layer.cornerRadius = 15
            mainView.layer.cornerRadius = 10
            imageView.layer.cornerRadius = 10
            thirdMainView.layer.cornerRadius = 10
            thirdImageView.layer.cornerRadius = 10
        }

        func setupCheckbox(_ checkbox: UIView, tag: Int) {
            checkbox.backgroundColor = .lightGray
            checkbox.layer.cornerRadius = 5
            checkbox.layer.borderColor = UIColor.gray.cgColor
            checkbox.tag = tag
            
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(toggleCheckbox(_:)))
            checkbox.addGestureRecognizer(tapGesture)
            checkbox.isUserInteractionEnabled = true
        }

        @objc func toggleCheckbox(_ sender: UITapGestureRecognizer) {
            guard let checkbox = sender.view else { return }

            let index = checkbox.tag
            isChecked[index].toggle()

            updateCheckboxAppearance(checkbox, isChecked: isChecked[index])
        }

        func updateCheckboxAppearance(_ checkbox: UIView, isChecked: Bool) {
            if isChecked {
                checkbox.backgroundColor = .systemBlue
                checkbox.layer.borderColor = UIColor.systemBlue.cgColor
            } else {
                checkbox.backgroundColor = .lightGray
                checkbox.layer.borderColor = UIColor.gray.cgColor
            }
        }
}
