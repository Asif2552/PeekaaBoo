

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
}
