//
//  BestSellarCollectionViewCell.swift
//  PeeKaaBoo.
//
//  Created by mac on 16/01/25.
//

import UIKit

class BestSellarCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var category: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var imgView: UIView!
    @IBOutlet weak var view: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        view.layer.cornerRadius = 10
        imgView.layer.cornerRadius = 10
    }

}
