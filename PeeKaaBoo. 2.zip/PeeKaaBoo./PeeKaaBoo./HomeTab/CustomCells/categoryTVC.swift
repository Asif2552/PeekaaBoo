//
//  categoryTVC.swift
//  PeeKaaBoo.
//
//  Created by mac on 13/01/25.
//

import UIKit

class categoryTVC: UICollectionViewCell {
    @IBOutlet weak var title: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var imgView: UIView!
    @IBOutlet weak var category: UILabel!
    
    @IBOutlet weak var widthConstraintsOfDetails: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        imgView.layer.cornerRadius = 10

    }

}
