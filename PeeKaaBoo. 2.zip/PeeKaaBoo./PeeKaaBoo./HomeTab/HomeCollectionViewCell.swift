//
//  HomeCollectionViewCell.swift
//  PeeKaaBoo.
//
//  Created by mac on 23/12/24.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var view: UIView!
    
    override func awakeFromNib() {
            super.awakeFromNib()
        
        self.view.layer.masksToBounds = true
        }
}
