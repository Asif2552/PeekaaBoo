import UIKit

class HomeViewController: UIViewController, UICollectionViewDelegate,  UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITextFieldDelegate{
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var bestSellarCollectionView: UICollectionView!

    @IBOutlet weak var btnDelete: UIView!
    
    @IBOutlet weak var categoryCell: UICollectionView!
    var titles = ["Chairs","Cupboard","Tables","Lambs","Ladders"]
    
    var products: [Product] = [
        Product(image: "image1", title: "Comfort Chair", price: 250.0, category: "Furniture"),
        Product(image: "image2", title: "Night Lamp", price: 40.5, category: "Lighting"),
    ]
    
    var productSellar: [ProductSeller] = [
        ProductSeller(image: "Rectangle 29", title: "Luxury Sofa", price: 1500.0, category: "Furniture"),
        ProductSeller(image: "Rectangle 33", title: "Elegant Lamp", price: 75.5, category: "Lighting"),
        ProductSeller(image: "Rectangle 35", title: "Study Desk", price: 300.0, category: "Office")
    ]
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var searchView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        searchView.layer.cornerRadius = 10
        searchView.layer.borderColor = UIColor.gray.cgColor
        searchView.layer.borderWidth = 0.5
        collectionView.delegate = self
        collectionView.dataSource = self
        
        bestSellarCollectionView.delegate = self
        bestSellarCollectionView.dataSource = self
        
        categoryCell.register(UINib(nibName: "categoryTVC", bundle: nil), forCellWithReuseIdentifier: "categoryTVC")
        
        bestSellarCollectionView.register(UINib(nibName: "BestSellarCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "BestSellarCollectionViewCell")
        categoryCell.delegate = self
        categoryCell.dataSource = self
        textField.delegate = self
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(deleteButtonTapped))
        btnDelete.addGestureRecognizer(tapGesture)
        btnDelete.isUserInteractionEnabled = true
    }
    
    @objc func deleteButtonTapped() {
        print("Delete button tapped")
        textField.text = ""

    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.categoryCell {
            return products.count
        } else if collectionView == self.collectionView {
            return titles.count
        } else if collectionView == self.bestSellarCollectionView {
            return productSellar.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.collectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCollectionViewCell", for: indexPath) as! HomeCollectionViewCell
            cell.title.text = titles[indexPath.row]
            cell.view.layer.cornerRadius = 8
            return cell
        } else if collectionView == categoryCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryTVC", for: indexPath) as! categoryTVC
            cell.widthConstraintsOfDetails.constant = (categoryCell.frame.size.width / 2) - 20
            let product = products[indexPath.row]
            cell.img.image = UIImage(named: product.image)
            return cell
        } else if collectionView == bestSellarCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BestSellarCollectionViewCell", for: indexPath) as! BestSellarCollectionViewCell
            let product = productSellar[indexPath.row]
            cell.img.image = UIImage(named: product.image)
            cell.title.text = product.title
            cell.price.text = "\(product.price)"
            cell.category.text = product.category
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.collectionView {
            let title = titles[indexPath.row]
            let font = UIFont(name: "Arial", size: 16)!
            let maxWidth: CGFloat = collectionView.bounds.width - 20
            let textSize = (title as NSString).size(withAttributes: [NSAttributedString.Key.font: font])
            let width = min(textSize.width + 20, maxWidth)
            return CGSize(width: width, height: 30)
        } else if collectionView == self.bestSellarCollectionView {
            return CGSize(width: 240, height: 110)
        }
        return CGSize(width: 300, height: 30)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("clicked")
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
    
}
