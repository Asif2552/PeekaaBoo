//
//  LoginViewController.swift
//  PeeKaaBoo.
//
//  Created by mac on 06/12/24.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var loginRedirection: UILabel!
    @IBOutlet weak var textFieldView: UIView!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var signUpView: UIView!
    @IBOutlet weak var passwordError: UILabel!
    @IBOutlet weak var emailError: UILabel!
    @IBOutlet weak var nameError: UILabel!
    @IBOutlet weak var submitBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        self.navigationController?.navigationBar.isHidden = true
        let textFieldBorder = CALayer()
        textFieldBorder.backgroundColor = UIColor.gray.cgColor
        textFieldBorder.frame = CGRect(x: 0, y: textFieldView.bounds.height - 1, width: textFieldView.bounds.width, height: 1)
        textFieldView.layer.addSublayer(textFieldBorder)
        
        let emailBorder = CALayer()
        emailBorder.backgroundColor = UIColor.gray.cgColor
        emailBorder.frame = CGRect(x: 0, y: emailView.bounds.height - 1, width: emailView.bounds.width, height: 1)
        emailView.layer.addSublayer(emailBorder)
        
        let passwordBorder = CALayer()
        passwordBorder.backgroundColor = UIColor.gray.cgColor
        passwordBorder.frame = CGRect(x: 0, y: passwordView.bounds.height - 1, width: passwordView.bounds.width, height: 1)
        passwordView.layer.addSublayer(passwordBorder)
        
        
        nameTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter your name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter your email",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter your password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        nameTextField.delegate = self
        self.hideKeyboardWhenTappedAround()
        signUpView.layer.cornerRadius = 7
        resetForm()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleLabelTap))
        loginRedirection.isUserInteractionEnabled = true
        loginRedirection.addGestureRecognizer(tapGesture)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tap)
        
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func resetForm() {
        submitBtn.isEnabled = true
        nameError.isHidden = false
        emailError.isHidden = false
        passwordError.isHidden = false
        
        nameTextField.text = ""
        emailTextField.text = ""
        passwordTextField.text = ""
    }
    
    @IBAction func submitButton(_ sender: UIButton) {
        if validateForm() {
            let name = nameTextField.text!
            let email = emailTextField.text!
            let password = passwordTextField.text!
            Auth.auth().createUser(withEmail: email, password: password) { (authResult, error) in
                if let error = error {
                    print("Error creating user: \(error.localizedDescription)")
                    return
                }
                
                guard let userId = authResult?.user.uid else { return }
                let db = Firestore.firestore()
                db.collection("users").document(userId).setData([
                    "name": name,
                    "email": email,
                    "password": password
                ]) { error in
                    if let error = error {
                        print("Error saving user data: \(error.localizedDescription)")
                    } else {
                        print("User data saved successfully")
                        self.nameTextField.text = ""
                        self.emailTextField.text = ""
                        self.passwordTextField.text = ""
                    }
                }
            }
            
        }
    }
    
    func validateForm() -> Bool {
        var isValid = true
        if let name = nameTextField.text, name.isEmpty {
            nameError.text = "Name is required."
            nameError.isHidden = false
            isValid = false
        } else {
            nameError.isHidden = true
        }
        
        if let email = emailTextField.text, email.isEmpty || !isValidEmail(email) {
            emailError.text = "Enter a valid email."
            emailError.isHidden = false
            isValid = false
        } else {
            emailError.isHidden = true
        }
        
        if let password = passwordTextField.text, password.isEmpty || password.count < 6 {
            passwordError.text = "Password must be at least 6 characters."
            passwordError.isHidden = false
            isValid = false
        } else {
            passwordError.isHidden = true
        }
        
        if isValid {
            print("Form is valid. Proceed with submission.")
        }
        
        return isValid
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
    }
    
    @objc func handleLabelTap() {
        print("Label tapped!") 
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignInViewController")as! SignInViewController
        navigationController?.pushViewController(vc, animated: true)
    }
}
