import UIKit

class MainViewController: UIViewController {
    
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var leftSideBarView: UIView!
    @IBOutlet weak var rightSideBarView: UIView!
    @IBOutlet weak var nextViewTitle: UILabel!
    @IBOutlet weak var imageView: UIView!
    @IBOutlet weak var miniHeadLabel: UILabel!
    @IBOutlet weak var headLabel: UILabel!
    @IBOutlet weak var nextView: UIView!
    @IBOutlet weak var nextViewButton: UIButton!
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pageControl.numberOfPages = 3
        pageControl.currentPage = 0
        nextViewButton.addTarget(self, action: #selector(nextButton), for: .touchUpInside)
        nextView.layer.cornerRadius = 10
        nextView.layer.borderColor = UIColor.white.cgColor
        nextView.layer.borderWidth = 1
        updatePage()
    }
    
    @objc func nextButton() {
        if pageControl.currentPage == 2 {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let nextPage = pageControl.currentPage + 1
            if nextPage < pageControl.numberOfPages {
                pageControl.currentPage = nextPage
                updatePage()
            }
        }
    }
    
    func updatePage() {
        switch pageControl.currentPage {
        case 0:
            headLabel.text = "Welcome to PeekaaBoo!"
            img.image = UIImage(named: "img6")
            miniHeadLabel.text = "Discover the best styles for you"
            leftSideBarView.isHidden = true
            rightSideBarView.layer.cornerRadius = 10
            rightSideBarView.layer.masksToBounds = true
            rightSideBarView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMinXMaxYCorner]
            
        case 1:
            headLabel.text = "Update trendy outfit"
            miniHeadLabel.text = "Favorite brand and hottest trends"
            img.image = UIImage(named: "img4")
            leftSideBarView.isHidden = false
            leftSideBarView.layer.cornerRadius = 10
            leftSideBarView.layer.masksToBounds = true
            leftSideBarView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMinYCorner, .layerMaxXMaxYCorner]
            
        case 2:
            headLabel.text = "Explore your true style"
            miniHeadLabel.text = "Relax let us bring the style for you"
            img.image = UIImage(named: "img1")
            leftSideBarView.isHidden = false
            rightSideBarView.isHidden = true
            nextViewTitle.text = "Lets go"
            leftSideBarView.layer.cornerRadius = 10
            leftSideBarView.layer.masksToBounds = true
            leftSideBarView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        default:
            break
        }
    }
}
