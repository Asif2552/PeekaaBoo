//
//  SellerProduct.swift
//  PeeKaaBoo.
//
//  Created by mac on 20/01/25.
//

import Foundation

struct ProductSeller {
    var image: String
    var title: String
    var price: Float
    var category: String
}
