//
//  ProfileTableViewCell.swift
//  PeeKaaBoo.
//
//  Created by mac on 18/01/25.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var ViewImage: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        ViewImage.layer.cornerRadius = 10


    }


}
