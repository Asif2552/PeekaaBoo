

import UIKit
import Firebase

class ProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var imageView: UIView!
    @IBOutlet weak var nameTitle: UILabel!
    @IBOutlet weak var emailTitle: UILabel!
    
    var tableCell = [
        ("Setting", "gearshape"),
        ("Notification", "bell"),
        ("Order History", "clock"),
        ("Privacy and Policy", "clock"),
        ("Logout", "clock")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUserData()
        imageView.layer.cornerRadius = imageView.frame.height / 2
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rowTitle = tableCell[indexPath.row].0
        if rowTitle == "Logout" {
            do{
                try Auth.auth().signOut()
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignInViewController")as! SignInViewController
                navigationController?.pushViewController(vc, animated: true)
            } catch let error as NSError {
                print("Error while logging out: \(error.localizedDescription)")
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 57
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableCell.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProfileTableViewCell", for: indexPath) as! ProfileTableViewCell
        cell.labelTitle.text = tableCell[indexPath.row].0
        cell.selectionStyle = .none
        tableView.separatorStyle = .none
        
        let imageName = tableCell[indexPath.row].1
        cell.img.image = UIImage(systemName: imageName)
        
        var accessoryImageView = UIImageView(image: UIImage(systemName: "chevron.right"))
        accessoryImageView.tintColor = .black
        
        if cell.labelTitle.text == "Order History" {
            accessoryImageView = UIImageView(image: UIImage(systemName: "arrow.forward.circle"))
            accessoryImageView.tintColor = .black
        }
        
        cell.accessoryView = accessoryImageView
        
        return cell
    }
    
    func fetchUserData() {
        guard let userId = Auth.auth().currentUser?.uid else {
            print("No user is logged in")
            return
        }
        
        let db = Firestore.firestore()
        
        db.collection("users").document(userId).getDocument { (document, error) in
            if let error = error {
                print("Error fetching user data: \(error.localizedDescription)")
                return
            }
            
            if let document = document, document.exists {
                let data = document.data()
                
                let name = data?["name"] as? String ?? "No Name Available"
                let email = data?["email"] as? String ?? "No Email Available"
                
                self.nameTitle.text = name
                self.emailTitle.text = email
                
            } else {
                print("User data not found in Firestore")
            }
        }
    }
    
}
