//
//  HomeCollectionViewCell.swift
//  PeeKaaBoo.
//
//  Created by mac on 07/12/24.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var img: UIImageView!
    
    override func awakeFromNib() {
           super.awakeFromNib()

           contentView.layer.cornerRadius = 10
           contentView.layer.masksToBounds = true
        
       }
}
