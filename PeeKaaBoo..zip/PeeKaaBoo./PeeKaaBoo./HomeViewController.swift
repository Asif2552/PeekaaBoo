import UIKit

class HomeViewController: UIViewController, UITableViewDataSource , UITableViewDelegate {
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var bannerImage: UIImageView!
    @IBOutlet weak var bannerView: UIView!
    @IBOutlet weak var furnitureView: UIView!
    @IBOutlet weak var accessoriesView: UIView!
    @IBOutlet weak var familyView: UIView!
    @IBOutlet weak var menView: UIView!
    
    let products: [Product] = [
        Product(image: "img1", title: "Floral Maxi Dress", price: 59.99, description: "Elegant floral maxi dress, perfect for casual outings or summer events.", stars: 5),
        Product(image: "img2", title: "Evening Gown", price: 129.99, description: "Stunning evening gown with lace details, ideal for formal occasions.", stars: 5),
        Product(image: "img4", title: "Wrap Dress", price: 49.99, description: "Chic wrap dress with a flattering silhouette and comfortable fit.", stars: 4),
        Product(image: "img3", title: "A-Line Dress", price: 39.99, description: "Classic A-line dress with short sleeves, suitable for both work and leisure.", stars: 4),
        Product(image: "img6", title: "Boho Midi Dress", price: 44.99, description: "Relaxed-fit boho midi dress with intricate embroidery, perfect for vacations.", stars: 4),
        Product(image: "img5", title: "Cocktail Dress", price: 79.99, description: "Stylish cocktail dress with a sleek design for evening parties.", stars: 5),
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        menView.layer.cornerRadius = 10
        furnitureView.layer.cornerRadius = 10
        accessoriesView.layer.cornerRadius = 10
        familyView.layer.cornerRadius = 10
        bannerView.layer.cornerRadius = 10
        bannerImage.layer.cornerRadius = 10
        table.delegate = self
        table.dataSource = self
        table.backgroundColor = .white
        table.separatorStyle = .none
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "HomeTableViewCell", for: indexPath)as! HomeTableViewCell
            cell.products = products
            cell.collection.reloadData()
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        240
    }
    
    
    
}
