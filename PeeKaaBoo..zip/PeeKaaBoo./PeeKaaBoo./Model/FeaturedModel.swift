import Foundation


struct Product {
    var image: String
    var title: String
    var price: Float
    var description: String
    var stars: Int
}
