import UIKit
import FirebaseAuth

class SignInViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var signupLabel: UILabel!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var emailError: UILabel!
    @IBOutlet weak var passwordError: UILabel!
    @IBOutlet weak var signInButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        setupTextFieldBorders()
        setupPlaceholders()
        loginView.layer.cornerRadius = 7
        emailTextField.delegate = self
        passwordTextField.delegate = self
        signInButton.addTarget(self, action: #selector(signInButtonTapped), for: .touchUpInside)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleLabelTap))
        signupLabel.isUserInteractionEnabled = true
        signupLabel.addGestureRecognizer(tapGesture)
    }
    
    func setupTextFieldBorders() {
        let emailBorder = CALayer()
        emailBorder.backgroundColor = UIColor.gray.cgColor
        emailBorder.frame = CGRect(x: 0, y: emailView.bounds.height - 1, width: emailView.bounds.width, height: 1)
        emailView.layer.addSublayer(emailBorder)
        
        let passwordBorder = CALayer()
        passwordBorder.backgroundColor = UIColor.gray.cgColor
        passwordBorder.frame = CGRect(x: 0, y: passwordView.bounds.height - 1, width: passwordView.bounds.width, height: 1)
        passwordView.layer.addSublayer(passwordBorder)
    }
    
    func setupPlaceholders() {
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter your email",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter your password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
    }
    
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func validateForm() -> Bool {
        var isValid = true
        
        if let email = emailTextField.text, email.isEmpty || !isValidEmail(email) {
            emailError.text = "Enter a valid email."
            emailError.isHidden = false
            isValid = false
        } else {
            emailError.isHidden = true
        }
        
        if let password = passwordTextField.text, password.isEmpty || password.count < 6 {
            passwordError.text = "Password must be at least 6 characters."
            passwordError.isHidden = false
            isValid = false
        } else {
            passwordError.isHidden = true
        }
        
        return isValid
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
    }
    
    @IBAction func signInButtonTapped(_ sender: UIButton) {
        if validateForm() {
            if validateForm() {
                let email = emailTextField.text!
                let password = passwordTextField.text!
                
                Auth.auth().signIn(withEmail: email, password: password) { (authResult, error) in
                    if let error = error {
                        self.showError(error.localizedDescription)
                        return
                    }
                    
                    print("User signed in successfully")
                    self.navigateToHome()
                }
            }        } else {
                print("Form is invalid")
            }
    }
    
    @objc func handleLabelTap() {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController")as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func showError(_ message: String) {
        let alert = UIAlertController(title: "Login Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func navigateToHome() {
        let storyboard = UIStoryboard(name: "Home", bundle: nil)
        if let tabBarController = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate
            sceneDelegate?.window?.rootViewController = tabBarController
            sceneDelegate?.window?.makeKeyAndVisible()
        }
    }
}
